package com.edgehub.datahub.storage;

import com.edgehub.datahub.config.HubProperties;
import com.edgehub.datahub.model.AlarmFactEvent;
import com.edgehub.datahub.model.DeviceStatusSnapshot;
import com.edgehub.datahub.model.ParsedHubMessage;
import com.edgehub.datahub.model.TelemetrySteadySummary;
import com.edgehub.datahub.monitoring.DataHubMetrics;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Component
@ConditionalOnProperty(prefix = "datahub.storage", name = "mode", havingValue = "file")
public final class FileArchiveTdengineWriter implements TdengineWriter {

  private static final Logger log = LoggerFactory.getLogger(FileArchiveTdengineWriter.class);

  private final Object writeLock = new Object();
  private final ObjectMapper objectMapper;
  private final DataHubMetrics metrics;
  private final Path baseDir;
  private final Path telemetryFile;
  private final Path telemetrySummaryFile;
  private final Path parameterSetFile;
  private final Path parameterAckFile;
  private final Path deviceStatusFile;
  private final Path alarmEventFile;

  public FileArchiveTdengineWriter(ObjectMapper objectMapper, HubProperties properties, DataHubMetrics metrics) {
    this.objectMapper = objectMapper;
    this.metrics = metrics;
    this.baseDir = Path.of(properties.getStorage().getBaseDir());
    this.telemetryFile = baseDir.resolve("telemetry.jsonl");
    this.telemetrySummaryFile = baseDir.resolve("telemetry-summary.jsonl");
    this.parameterSetFile = baseDir.resolve("params-set.jsonl");
    this.parameterAckFile = baseDir.resolve("params-ack.jsonl");
    this.deviceStatusFile = baseDir.resolve("device-status.jsonl");
    this.alarmEventFile = baseDir.resolve("alarm-events.jsonl");
    createBaseDirectory();
  }

  @Override
  public Mono<Void> writeTelemetry(ParsedHubMessage.TelemetryMessage telemetry) {
    return appendJsonLine(telemetryFile, "telemetry", telemetry.receivedAt(), telemetry.topic().deviceId(), Map.of(
        "topic", telemetry.topic().rawTopic(),
        "payload", telemetry.payload()))
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  @Override
  public Mono<Void> writeTelemetrySummary(TelemetrySteadySummary summary) {
    return appendJsonLine(
        telemetrySummaryFile,
        "telemetry_summary",
        summary.windowEnd(),
        summary.deviceId(),
        Map.of(
            "topic", summary.rawTopic(),
            "payload", summary))
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  @Override
  public Mono<Void> writeParameterSet(ParsedHubMessage.ParameterSetMessage parameterSet) {
    return appendJsonLine(
        parameterSetFile,
        "params_set",
        parameterSet.receivedAt(),
        parameterSet.topic().deviceId(),
        Map.of(
            "topic", parameterSet.topic().rawTopic(),
            "payload", parameterSet.payload()))
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  @Override
  public Mono<Void> writeParameterAck(ParsedHubMessage.ParameterAckMessage parameterAck) {
    return appendJsonLine(
        parameterAckFile,
        "params_ack",
        parameterAck.receivedAt(),
        parameterAck.topic().deviceId(),
        Map.of(
            "topic", parameterAck.topic().rawTopic(),
            "payload", parameterAck.payload()))
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  @Override
  public Mono<Void> writeDeviceStatus(DeviceStatusSnapshot status) {
    return appendJsonLine(
        deviceStatusFile,
        "device_status",
        status.observedAt(),
        status.deviceId(),
        Map.of(
            "topic", status.rawTopic(),
            "payload", status))
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  @Override
  public Mono<Void> writeAlarmFact(AlarmFactEvent alarmFactEvent) {
    Map<String, Object> payload = new LinkedHashMap<>();
    payload.put("rule_code", alarmFactEvent.ruleCode());
    payload.put("severity", alarmFactEvent.severity());
    payload.put("source", alarmFactEvent.source());
    payload.put("reason", alarmFactEvent.reason());
    payload.put("event_type", alarmFactEvent.eventType());
    payload.put("triggered_at", alarmFactEvent.triggeredAt());
    payload.put("duration_seconds", alarmFactEvent.durationSeconds());
    payload.put("context_json", alarmFactEvent.contextJson());
    return appendJsonLine(
        alarmEventFile,
        "alarm_event",
        alarmFactEvent.eventTime(),
        alarmFactEvent.deviceId(),
        payload)
        .doOnSuccess(ignored -> metrics.recordTdengineWriteSuccess())
        .doOnError(ignored -> metrics.recordTdengineWriteFailed());
  }

  private Mono<Void> appendJsonLine(
      Path targetFile,
      String eventType,
      Instant receivedAt,
      String deviceId,
      Map<String, Object> content) {
    return Mono.fromRunnable(() -> {
          try {
            Map<String, Object> envelope = new LinkedHashMap<>();
            envelope.put("event_type", eventType);
            envelope.put("device_id", deviceId);
            envelope.put("received_at", receivedAt);
            envelope.putAll(content);
            byte[] line = (objectMapper.writeValueAsString(envelope) + System.lineSeparator())
                .getBytes(StandardCharsets.UTF_8);
            synchronized (writeLock) {
              Files.write(
                  targetFile,
                  line,
                  StandardOpenOption.CREATE,
                  StandardOpenOption.WRITE,
                  StandardOpenOption.APPEND);
            }
          } catch (IOException exception) {
            throw new IllegalStateException("failed to append archive file: " + targetFile, exception);
          }
        })
        .doOnSuccess(ignored -> log.debug("archived {} event to {}", eventType, targetFile))
        .subscribeOn(Schedulers.boundedElastic())
        .then();
  }

  private void createBaseDirectory() {
    try {
      Files.createDirectories(baseDir);
    } catch (IOException exception) {
      throw new IllegalStateException("failed to create archive directory: " + baseDir, exception);
    }
  }
}
